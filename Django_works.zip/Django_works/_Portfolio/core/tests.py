from django.test import TestCase
from django.urls import reverse
from .models import Contact

class PortfolioPagesTest(TestCase):
    def test_home_page(self):
        response = self.client.get(reverse('index'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'index.html')

    def test_about_page(self):
        response = self.client.get(reverse('about'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Fullstack Developer")

    def test_projects_page(self):
        response = self.client.get(reverse('projects'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "My Portfolio")

    def test_contact_page(self):
        response = self.client.get(reverse('contact'))
        self.assertEqual(response.status_code, 200)

    def test_contact_form_submission(self):
        form_data = {
            'name': 'Test User',
            'email': 'test@example.com',
            'message': 'Hello, I like your portfolio!'
        }
        response = self.client.post(reverse('contact'), form_data)
        self.assertRedirects(response, reverse('contact'))
        self.assertEqual(Contact.objects.count(), 1)

from django.db import models

# Create your models here.
class Profile(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='profile/')
    bio = models.TextField()
    cv_link = models.URLField()

class Skill(models.Model):
    name = models.CharField(max_length=100)
    level = models.IntegerField()  # Use % or level indicator

class Project(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='projects/')
    technologies = models.CharField(max_length=200)
    link = models.URLField(blank=True)

class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

